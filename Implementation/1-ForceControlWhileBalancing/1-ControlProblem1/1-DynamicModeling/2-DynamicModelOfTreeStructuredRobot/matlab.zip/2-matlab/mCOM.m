function MS = mCOM(f, key)

param = f(key).param;
MS = param(2:4)';