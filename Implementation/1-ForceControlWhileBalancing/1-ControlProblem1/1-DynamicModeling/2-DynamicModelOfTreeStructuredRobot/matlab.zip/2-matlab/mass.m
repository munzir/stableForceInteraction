function m = mass(f, key)

param = f(key).param;
m = param(1);